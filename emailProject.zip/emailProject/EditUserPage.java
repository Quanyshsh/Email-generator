import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.sql.*;
import java.security.SecureRandom;

public class EditUserPage extends JFrame {
    private JTextField firstNameField;
    private JTextField lastNameField;
    private JTextField departmentField;
    private JTextField passwordField;
    private JTextField mailboxCapacityField;
    private JTextField altEmailField;

    private static final String JDBC_URL = "jdbc:mysql://localhost:3306/email";
    private static final String USER = "root";
    private static final String PASSWORD = "";

    public EditUserPage() {
        setTitle("Edit User Information");
        setSize(400, 300);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);

        JPanel panel = new JPanel(new GridLayout(8, 2, 10, 10));
        panel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        JLabel firstNameLabel = new JLabel("First Name:");
        firstNameField = new JTextField();

        JLabel lastNameLabel = new JLabel("Last Name:");
        lastNameField = new JTextField();

        JLabel departmentLabel = new JLabel("Department:");
        departmentField = new JTextField();

        JLabel passwordLabel = new JLabel("Password:");
        passwordField = new JTextField();

        JLabel mailboxCapacityLabel = new JLabel("Mailbox Capacity:");
        mailboxCapacityField = new JTextField();

        JLabel altEmailLabel = new JLabel("Alternative Email:");
        altEmailField = new JTextField();

        JButton generateEmailButton = new JButton("Generate Email");
        generateEmailButton.addActionListener(this::generateEmail);

        JButton generatePasswordButton = new JButton("Generate Password");
        generatePasswordButton.addActionListener(this::generatePassword);

        JButton saveButton = new JButton("Save");
        saveButton.addActionListener(this::saveUser);

        panel.add(firstNameLabel);
        panel.add(firstNameField);
        panel.add(lastNameLabel);
        panel.add(lastNameField);
        panel.add(departmentLabel);
        panel.add(departmentField);
        panel.add(passwordLabel);
        panel.add(passwordField);
        panel.add(mailboxCapacityLabel);
        panel.add(mailboxCapacityField);
        panel.add(altEmailLabel);
        panel.add(altEmailField);
        panel.add(generateEmailButton);
        panel.add(generatePasswordButton);
        panel.add(saveButton);

        add(panel);
        setVisible(true);
    }

    private void generateEmail(ActionEvent e) {
        String generatedEmail = generateEmailSyntax(
                firstNameField.getText(),
                lastNameField.getText(),
                departmentField.getText()
        );
        altEmailField.setText(generatedEmail);
    }

    private void generatePassword(ActionEvent e) {
        String generatedPassword = generateRandomPassword(12); // Change the length as needed
        passwordField.setText(generatedPassword);
    }

    private String generateEmailSyntax(String firstName, String lastName, String department) {
        return firstName.toLowerCase() + "." + lastName.toLowerCase() + "@" + department.toLowerCase() + ".company.com";
    }

    private String generateRandomPassword(int length) {
        String chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789!@#$%^&*()-_=+";
        SecureRandom random = new SecureRandom();
        StringBuilder password = new StringBuilder();

        for (int i = 0; i < length; i++) {
            int randomIndex = random.nextInt(chars.length());
            password.append(chars.charAt(randomIndex));
        }

        return password.toString();
    }

    private void saveUser(ActionEvent e) {
        try (Connection connection = DriverManager.getConnection(JDBC_URL, USER, PASSWORD)) {
            String insertQuery = "INSERT INTO info (first_name, last_name, department, password, mailbox_capacity, alt_email) VALUES (?, ?, ?, ?, ?, ?)";
            try (PreparedStatement preparedStatement = connection.prepareStatement(insertQuery)) {
                preparedStatement.setString(1, firstNameField.getText());
                preparedStatement.setString(2, lastNameField.getText());
                preparedStatement.setString(3, departmentField.getText());
                preparedStatement.setString(4, passwordField.getText());
                preparedStatement.setInt(5, Integer.parseInt(mailboxCapacityField.getText()));
                preparedStatement.setString(6, altEmailField.getText());

                int insertedRows = preparedStatement.executeUpdate();

                if (insertedRows > 0) {
                    JOptionPane.showMessageDialog(this, "User information saved successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);
                } else {
                    JOptionPane.showMessageDialog(this, "Error saving user information.", "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        } catch (SQLException | NumberFormatException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error saving user information.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(EditUserPage::new);
    }
}
/*CREATE TABLE info (
    id INT PRIMARY KEY AUTO_INCREMENT,
    first_name VARCHAR(255),
    last_name VARCHAR(255),
    department VARCHAR(255),
    password VARCHAR(255),
    mailbox_capacity INT,
    alt_email VARCHAR(255)
);
*/
