import javax.swing.*;
import java.awt.*;
import java.sql.*;
import java.util.concurrent.ExecutionException;

public class LoginPage extends JFrame {
    private JTextField usernameField;
    private JPasswordField passwordField;
    private static final String JDBC_URL = "jdbc:mysql://localhost:3306/email";
    private static final String USER = "root";
    private static final String PASSWORD = "";

    public LoginPage() {
        setTitle("Вход");
        setSize(350, 200);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);

        JPanel panel = new JPanel(new GridLayout(4, 1, 10, 10));
        panel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));




        JLabel usernameLabel = new JLabel("Имя пользователя:");
        usernameField = new JTextField();

        JLabel passwordLabel = new JLabel("Пароль:");
        passwordField = new JPasswordField();

        JButton loginButton = new JButton("Войти");
        loginButton.setBackground(new Color(0, 102, 204));
        loginButton.setForeground(Color.WHITE);
        loginButton.setFocusPainted(false);
        loginButton.addActionListener(e -> new LoginTask().execute());


        panel.add(usernameLabel);
        panel.add(usernameField);
        panel.add(passwordLabel);
        panel.add(passwordField);
        panel.add(loginButton);

        add(panel);
        setVisible(true);
    }

    private class LoginTask extends SwingWorker<Boolean, Void> {
        @Override
        protected Boolean doInBackground() {
            String username = usernameField.getText();
            char[] passwordChars = passwordField.getPassword();
            String password = new String(passwordChars);

            if (!username.isEmpty() && passwordChars.length > 0) {
                return checkCredentials(username, password);
            }
            return false;
        }

        @Override
        protected void done() {
            try {
                if (get()) {
                    JOptionPane.showMessageDialog(LoginPage.this, "Вход выполнен успешно!", "Успех", JOptionPane.INFORMATION_MESSAGE);
                    //SwingUtilities.invokeLater(() -> new TodoListPage());
                    dispose();
                    SwingUtilities.invokeLater(() -> new EditUserPage());

                } else {
                    JOptionPane.showMessageDialog(LoginPage.this, "Неверное имя пользователя или пароль", "Ошибка", JOptionPane.ERROR_MESSAGE);
                }
            } catch (InterruptedException | ExecutionException e) {
                e.printStackTrace();
            }
        }
    }

    private boolean checkCredentials(String username, String password) {
        try (Connection connection = DriverManager.getConnection(JDBC_URL, USER, PASSWORD)) {
            String query = "SELECT * FROM users WHERE username = ? AND password = ?";
            try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
                preparedStatement.setString(1, username);
                preparedStatement.setString(2, password);
                ResultSet resultSet = preparedStatement.executeQuery();
                return resultSet.next();
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
            return false;
        }
    }
}
