import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class MainApp {
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> createAndShowGUI());
    }

    private static void createAndShowGUI() {
        JFrame frame = new JFrame("Список дел");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(400, 250);
        frame.setLayout(new FlowLayout(FlowLayout.CENTER, 10, 10));
        frame.getContentPane().setBackground(new Color(255, 255, 255));

        JPanel panel = new JPanel();
        panel.setBackground(new Color(240, 240, 240));
        panel.setLayout(new GridLayout(3, 1, 0, 10));

        JButton registrationButton = createStyledButton("Регистрация");
        registrationButton.addActionListener(e -> SwingUtilities.invokeLater(() -> new RegistrationPage()));

        JButton loginButton = createStyledButton("Вход");
        loginButton.addActionListener(e -> SwingUtilities.invokeLater(() -> new LoginPage()));

        JButton adminButton = createStyledButton("Админ");
        adminButton.addActionListener( e -> SwingUtilities.invokeLater(() -> new LoginPage2()));

        panel.add(registrationButton);
        panel.add(loginButton);
        panel.add(adminButton);

        frame.add(panel);
        frame.setVisible(true);
    }

    private static JButton createStyledButton(String text) {
        JButton button = new JButton(text);
        button.setBackground(new Color(135, 206, 250));
        button.setForeground(Color.WHITE);
        button.setFocusPainted(false);
        button.setFont(new Font("Arial", Font.BOLD, 16));
        button.setBorderPainted(false);
        button.setCursor(new Cursor(Cursor.HAND_CURSOR));
        button.setPreferredSize(new Dimension(150, 40));
        return button;
    }
}
