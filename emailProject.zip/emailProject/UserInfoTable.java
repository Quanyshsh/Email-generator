import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.sql.*;
import javax.swing.table.DefaultTableModel;

public class UserInfoTable extends JFrame {
    private JTable table;
    private JButton editButton;

    private static final String JDBC_URL = "jdbc:mysql://localhost:3306/email";
    private static final String USER = "root";
    private static final String PASSWORD = "";

    public UserInfoTable() {
        setTitle("User Information Table");
        setSize(800, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        // Create a table model
        DefaultTableModel tableModel = new DefaultTableModel();
        tableModel.addColumn("ID");
        tableModel.addColumn("First Name");
        tableModel.addColumn("Last Name");
        tableModel.addColumn("Department");
        tableModel.addColumn("Password");
        tableModel.addColumn("Mailbox Capacity");
        tableModel.addColumn("Alt Email");

        // Fetch data from the database and populate the table model
        fetchUserData(tableModel);

        // Create the JTable
        table = new JTable(tableModel);
        table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);

        // Create the JScrollPane
        JScrollPane scrollPane = new JScrollPane(table);

        // Create the Edit button
        editButton = new JButton("Edit Selected Row");
        editButton.addActionListener(this::editSelectedRow);

        // Add components to the frame
        add(scrollPane, BorderLayout.CENTER);
        add(editButton, BorderLayout.SOUTH);

        setVisible(true);
    }

    private void fetchUserData(DefaultTableModel tableModel) {
        try (Connection connection = DriverManager.getConnection(JDBC_URL, USER, PASSWORD)) {
            String query = "SELECT * FROM info";
            try (Statement statement = connection.createStatement()) {
                ResultSet resultSet = statement.executeQuery(query);

                while (resultSet.next()) {
                    Object[] rowData = {
                            resultSet.getInt("id"),
                            resultSet.getString("first_name"),
                            resultSet.getString("last_name"),
                            resultSet.getString("department"),
                            resultSet.getString("password"),
                            resultSet.getInt("mailbox_capacity"),
                            resultSet.getString("alt_email")
                    };
                    tableModel.addRow(rowData);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void editSelectedRow(ActionEvent e) {
        int selectedRow = table.getSelectedRow();
        if (selectedRow != -1) {
            // Get data from the selected row
            int userId = (int) table.getValueAt(selectedRow, 0);
            String firstName = (String) table.getValueAt(selectedRow, 1);
            String lastName = (String) table.getValueAt(selectedRow, 2);
            String department = (String) table.getValueAt(selectedRow, 3);
            String password = (String) table.getValueAt(selectedRow, 4);
            int mailboxCapacity = (int) table.getValueAt(selectedRow, 5);
            String altEmail = (String) table.getValueAt(selectedRow, 6);

            // Open the EditUserPage with the selected user data
            SwingUtilities.invokeLater(() -> new EditUserPage());
        } else {
            JOptionPane.showMessageDialog(this, "Please select a row to edit.", "Info", JOptionPane.INFORMATION_MESSAGE);
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(UserInfoTable::new);
    }
}
