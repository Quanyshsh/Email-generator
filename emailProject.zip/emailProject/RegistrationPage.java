import javax.swing.*;
import java.awt.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class RegistrationPage extends JFrame {
    private JTextField usernameField;
    private JPasswordField passwordField;
    private JPasswordField confirmPasswordField;
    private JTextField lastNameField;
    private static final String JDBC_URL = "jdbc:mysql://localhost:3306/email";
    private static final String USER = "root";
    private static final String PASSWORD = "";

    public RegistrationPage() {
        setTitle("Регистрация");
        setSize(650, 250);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);

        JPanel panel = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();

        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 2;
        gbc.insets = new Insets(10, 10, 10, 10);

        JLabel titleLabel = new JLabel("Регистрация");
        titleLabel.setFont(new Font("Arial", Font.BOLD, 18));
        panel.add(titleLabel, gbc);

        gbc.gridy++;
        gbc.gridwidth = 1;
        panel.add(new JLabel("Имя:"), gbc);

        gbc.gridx++;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        usernameField = new JTextField(20);
        panel.add(usernameField, gbc);

        gbc.gridx = 0;
        gbc.gridy++;
        panel.add(new JLabel("Фамилия:"), gbc);

        gbc.gridx++;
        lastNameField = new JTextField(20);
        panel.add(lastNameField, gbc);

        gbc.gridx = 0;
        gbc.gridy++;
        panel.add(new JLabel("Пароль:"), gbc);

        gbc.gridx++;
        passwordField = new JPasswordField(20);
        panel.add(passwordField, gbc);

        gbc.gridx = 0;
        gbc.gridy++;
        panel.add(new JLabel("Подтвердите пароль:"), gbc);

        gbc.gridx++;
        confirmPasswordField = new JPasswordField(20);
        panel.add(confirmPasswordField, gbc);

        gbc.gridx = 0;
        gbc.gridy++;
        gbc.gridwidth = 2;
        gbc.fill = GridBagConstraints.NONE;
        JButton registerButton = new JButton("Зарегистрироваться");
        registerButton.setBackground(new Color(0, 102, 204));
        registerButton.setForeground(Color.WHITE);
        registerButton.setFocusPainted(false);
        registerButton.addActionListener(e -> registerUser());
        panel.add(registerButton, gbc);

        add(panel);
        setVisible(true);
    }

    private void registerUser() {
        String username = usernameField.getText();
        String password = new String(passwordField.getPassword());
        String confirmPassword = new String(confirmPasswordField.getPassword());

        if (password.equals(confirmPassword)) {
            try (Connection connection = DriverManager.getConnection(JDBC_URL, USER, PASSWORD)) {
                if (connection != null) {
                    JOptionPane.showMessageDialog(this, "Подключение к базе данных успешно.");
                } else {
                    JOptionPane.showMessageDialog(this, "Не удалось подключиться к базе данных.", "Ошибка", JOptionPane.ERROR_MESSAGE);
                }

                String query = "INSERT INTO users (username, password, last_name) VALUES (?, ?, ?)";
                try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
                    preparedStatement.setString(1, username);
                    preparedStatement.setString(2, password);
                    preparedStatement.setString(3, lastNameField.getText());
                    preparedStatement.executeUpdate();
                }

                JOptionPane.showMessageDialog(this, "Пользователь успешно зарегистрирован.");
                dispose();
                SwingUtilities.invokeLater(() -> new LoginPage());

            } catch (SQLException e) {
                e.printStackTrace();
                JOptionPane.showMessageDialog(this, "Ошибка при регистрации пользователя.", "Ошибка", JOptionPane.ERROR_MESSAGE);
            }

        } else {
            JOptionPane.showMessageDialog(this, "Пароль и подтверждение пароля не совпадают.", "Ошибка", JOptionPane.ERROR_MESSAGE);
        }
    }
}
